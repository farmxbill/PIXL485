/***********************************************************************************************//**
  @file         Versions.h
  @date         $Date:$      
  @version      $Revision:$    

  @brief        Version Info
  
 **************************************************************************************************/

#ifndef __VERSIONS_H
#define __VERSIONS_H

#define VERSION_MAJOR   1
#define VERSION_MINOR   0
#define VERSION_REV     0


#endif //__VERSIONS_H
