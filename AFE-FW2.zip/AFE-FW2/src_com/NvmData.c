/***********************************************************************************************//**
  @file         NvmData.c
  @date         $Date:$
  @version      $Revision:$

  @brief        Nvm Data Definitions

 **************************************************************************************************/

#include <stdint.h>
#include <xc.h>
#include "NvmData.h"
#include "memory.h"
 
/**************************************************************************************************
*              NV DATA DEFINITIONS
**************************************************************************************************/

// Initialize EEPROM defaults in Hex file
__EEPROM_DATA( (DEFAULT_HWID & 0xff), (DEFAULT_HWID >> 8), 
                DEFAULT_OSC_DELAY,
                DEFAULT_MEAS_PERIOD,
                SENS_TYPE,
                0xff,0xff,0xff     // unused
             );

/**************************************************************************************************
*              GLOBAL NV SHADOW VARS
**************************************************************************************************/

uint8_t gOscDelay;
uint8_t gMeasPeriod;
uint16_t gHw_ID;
uint8_t gSensorType;

/**********************************************************************************************//**
 * @brief   Initialize global variables from NVRAM
 *          
 * @param   NONE
 * 
 * @return  NONE
 ***************************************************************************************************/  
void NVM_ReadGlobals( void )
{
    gOscDelay = DATAEE_ReadByte(NVADRS_OSC_DELAY);
    gMeasPeriod = DATAEE_ReadByte(NVADRS_MEAS_PERIOD);  
    gHw_ID = (uint16_t) (DATAEE_ReadByte(NVADRS_HWID) + (DATAEE_ReadByte(NVADRS_HWID+1)<<8));
    gSensorType = (uint8_t)(DATAEE_ReadByte(NVADRS_SENS_TYPE));
}

